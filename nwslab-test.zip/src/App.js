import './App.css';
import {ListOfCats} from "./pages/ListOfCats/ListOfCats";

function App() {
  return (
    <div>
       <ListOfCats/>
    </div>
  );
}

export default App;
