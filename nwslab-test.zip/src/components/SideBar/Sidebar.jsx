import React, {useEffect} from "react"
import "./sidebar.scss"
import {NavLink,matchPath} from "react-router-dom";

export const Sidebar = ({catsCategories}) => {

    return (
        <div className="sidebar">
        {catsCategories && catsCategories.map((item, index)=> (
            <NavLink
                key={item.id}
                to={`/` + item.id}
                className="nav"
                activeClassname="nav-active">
                {item.name}
            </NavLink>
        ))}
    </div>
    )
}
